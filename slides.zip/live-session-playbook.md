# Live session playbook — Incheon resilience workshop

For Shreyasi/Anurag to run during tomorrow's 20-minute presentation window, and to
test on today's 3pm call before relying on it live.

---

## Role split (confirm on the 3pm call)

- **Presenter**: gives the 20-minute talk. Not touching Mentimeter/AI during this window.
- **Virtual host** (Shreyasi or Anurag, pick one): owns Mentimeter results, runs the
  clustering step, pastes the output into the two placeholder slides. Not doing
  anything else during the 20 minutes.
- **Second pair of hands** (the other of the two): backup on the clustering step,
  watches the clock, flags if timing is slipping so the host can switch to the
  fallback path early rather than late.

---

## Primary path: Mentimeter → Miro

1. Open the live Mentimeter results for Q1/Q2 in your own browser tab (needs
   viewer/editor access to the presentation — set this up before tomorrow).
2. Export responses to Miro as sticky notes.
3. Run Miro AI "cluster by theme" on the board.
4. Manually relabel the clusters using the fixed category vocabulary below (Miro's
   automatic labels won't know about CDRI or Sendai framing — swap them in).
5. Screenshot the clustered board, paste into the matching placeholder slide.

**Test today:** confirm the Mentimeter→Miro export works while the presentation is
still *open* (not formally closed) — that's the one unverified step. If it only
works after closing the session, this path is dead for a live 20-minute window and
you go straight to the fallback below.

---

## Fallback path: copy responses → AI prompt → Mermaid render

Use this if the Miro export needs a closed session, or if it's too slow on the day.

### Step 1 — copy the raw responses
From the Mentimeter results view, copy every submitted answer for the question as a
plain list (one per line).

### Step 2 — paste into one of these two prompts (use with Claude/ChatGPT)

**Prompt for Q1 — "What are the three biggest drivers of disaster risk in your country?"**

```
You are helping synthesize live audience responses from a workshop with national
disaster-risk delegations.

QUESTION ASKED: "What are the three biggest drivers of disaster risk in your country?"

RAW RESPONSES (one per line, from ~40 delegates, may repeat, may be terse, may need
light translation):
{PASTE RESPONSES HERE}

TASK:
1. Merge near-duplicates. Translate any non-English text to English, preserving
   original meaning.
2. Cluster every response under exactly these five categories (Climate and Disaster
   Resilience Index dimensions) — do not invent new top-level categories:
   - Physical (built environment)
   - Natural (natural environment)
   - Social
   - Economic and livelihoods
   - Institutional capacities
   A response may fit more than one category — pick the single best fit.
3. Within each category, group similar responses into 2-4 short theme labels
   (3-6 words), and note how many delegates raised each theme, e.g. "Weak land-use
   enforcement (6)".
4. Output ONLY a Mermaid mindmap in this exact format, nothing else — no preamble,
   no explanation:

mindmap
  root((Drivers of disaster risk))
    Physical
      Theme A (n)
      Theme B (n)
    Natural
      Theme C (n)
    Social
      Theme D (n)
    Economic and livelihoods
      Theme E (n)
    Institutional capacities
      Theme F (n)

Keep every leaf label under 6 words. Omit a category entirely if it got zero
responses — do not invent content to fill it.
```

**Prompt for Q2 — "Which population is most likely to be left behind during disasters?"**

```
You are helping synthesize live audience responses from a workshop with national
disaster-risk delegations.

QUESTION ASKED: "Which population is most likely to be left behind during disasters?"

RAW RESPONSES (one per line, from ~40 delegates, may repeat, may be terse, may need
light translation):
{PASTE RESPONSES HERE}

TASK:
1. Merge near-duplicates. Translate any non-English text to English, preserving
   original meaning.
2. Cluster responses under these Sendai Framework vulnerable-population categories.
   Reuse this list; only add a new branch if a response clearly doesn't fit any of
   them:
   - Older persons
   - Persons with disabilities
   - Women and girls
   - Children
   - Poor / economically marginalized households
   - Informal settlement residents
   - Migrants and displaced people
   - Indigenous / ethnic minority groups
   - Remote / hard-to-reach rural populations
3. Within each populated category, note the specific reason delegates gave (short
   phrase) and how many raised it, e.g. "No independent means of evacuation (5)".
4. Output ONLY a Mermaid mindmap in this exact format, nothing else — no preamble,
   no explanation:

mindmap
  root((Leaving no one behind))
    Older persons
      reason (n)
    Persons with disabilities
      reason (n)

Keep every leaf label under 6 words. Omit a category entirely if it got zero
responses — do not invent content to fill it.
```

### Step 3 — render and export
1. Copy the mermaid code the AI returns.
2. Go to mermaid.live, paste into the left pane.
3. Click Export → PNG (top right).
4. Paste the PNG into the matching placeholder slide (slide 1 for Q1, slide 2 for Q2).

---

## Timing rehearsal (do this on the 3pm call)

1. Submit ~15-20 dummy answers to each Mentimeter question — mix in duplicates, a
   couple of terse one-word answers, and a couple of non-English phrases so the test
   isn't cleaner than reality will be.
2. Run the primary path (Miro) end to end. Time it.
3. Run the fallback path end to end. Time it.
4. Whichever path you commit to for tomorrow, it needs to comfortably fit inside the
   20-minute presentation window — target under 8 minutes per question, so there's
   margin if the room's answers are messier or slower to arrive than the test.
5. Decide now, not tomorrow morning: which path is primary, who is the virtual host,
   and what the trigger is for switching to fallback mid-session (e.g. "if Miro
   export hasn't produced a board within 5 minutes, switch to mermaid").

---

## Slide checklist (deck order, per the mail)

1. Drivers of disaster risk — live synthesis (Q1 mindmap)
2. Leaving no one behind — live synthesis (Q2 mindmap)
3. Physical (built environment) — schematic map
4. Natural (natural environment) — schematic map
5. Social — schematic map
6. Economic and livelihoods — schematic map
7. Institutional capacities — schematic map
8. Discussion prompt: "How useful is this, and how would you use it in your work?"

Slides 3-7 are already built: `D:\ANSHUTALK\slides\slide-*.png`.
